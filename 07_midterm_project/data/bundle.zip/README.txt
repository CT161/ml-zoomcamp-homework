FIA tree species code changes through time

Authors: Jonathan Knott, Jianmin Wang, David Walker, Grant Domke, Songlin Fei

Contact: jonathan.knott@usda.gov

Description:
This repository contains data and R code that evaluates changes in species code (SPCD) within USDA Forest Service Forest Inventory and Analysis (FIA) Program tree remeasurements. The FIA Program conducts the national forest inventory of the United States, with a spatially representative sample of over 140,000 forested plots across the conterminous U.S. (CONUS), Alaska, Hawaii, and the U.S. Territories and Affiliated Islands. In this project, we linked remeasurements of individual trees across CONUS FIA plots to determine how often tree species identification (SPCD) changed over time for each tree, how often SPCD changes occurred across the country, and how decisions to rectify these changes can lead to differences in estimates of species range centroids, plot-level species richness, and both tree-level and population-level estimates of aboveground carbon. 

Data file information:
The data file included in this repository (trees_through_time_20250429.csv) contains a table in CSV format that includes >3 million unique trees that have been remeasured in FIA plots. The table includes columns of tree control number (CN) for the most recent measurement of live trees and their previous CNs through past measurements. These CNs can be used to link to additional tree-level data from the FIA database. This table also includes columns of tree SPCD at each remeasurement, columns flagging whether the SPCD changed between remeasurements, and what each tree's first and current recorded SPCDs were. CNs can be used to link/filter additional tree-level data from the FIA database tree (TREE) table, which can be further linked with other FIA database tables such as the plot (PLOT) and condition (COND) tables.

The columns in the data file are:
- CN: the control number of the most recent measurement of each tree.
- PREV_TRE_CN[1-6]: the CN of the previous measurements of each tree. Note that PREV_TRE_CN6 is NA for all trees since the maximum number of remeasurements as of the time of the data pull (6 January 2025) was six (i.e., PREV_TRE_CN6 represents seven remeasurements).
- SPCD1: the species code (SPCD) of the most recent measurement of each tree (i.e., from CN).
- SPCD[2-6]: the SPCD of the previous measurements of each tree (i.e., from PREV_TRE_CN[1-5]. SPCD2 is the SPCD associated with PREV_TRE_CN1, SPCD3 is the SPCD associated with PREV_TRE_CN2, etc.)
- dif[1-5]: difference in SPCD between subsequent remeasurements (i.e., dif1 is the difference between the current and first previous SPCD, dif2 is the difference between the first and second previous SPCD, etc.). Zeros represent no change in SPCD. Non-zero values of dif[1-5] do not represent magnitude of change; they are only used to represent whether or not a change in SPCD occurred.
- difs: a flag indicating whether SPCD changed between any remeasurements
- SPCD_T1: SPCD of the first measurement. Because trees have different numbers of remeasurements, this column was derived to figure out the first occurring SPCD (i.e., earliest non-NA value from SPCD[2-6]).
- TRE_CN_T1: Tree CN of the first measurement.

R code information:
The R code (spp_mismatch_example.R) included in this repository was used to construct the data file. It includes instructions for downloading the SQLite FIA database from the FIA DataMart (https://apps.fs.usda.gov/fia/datamart/datamart.html), how to use the 'odbc' and 'RSQLite' packages to perform SQL queries on the database, and steps for constructing the trees-through-time data table using the 'dplyr' and 'data.table' packages. The script was written and run in R version 4.4.2 on 29 April 2025 using a copy of the FIA database downloaded on 6 January 2025. 

References:

Barrett T, Dowle M, Srinivasan A, Gorecki J, Chirico M, Hocking T, Schwendinger B (2024). data.table: Extension of `data.frame`. R package version 1.16.0. https://CRAN.R-project.org/package=data.table

Hester J, Wickham H, Gjoneski O (2024). odbc: Connect to ODBC Compatible Databases (using the DBI Interface). R package version 1.5.0. https://CRAN.R-project.org/package=odbc

Müller K, Wickham H, James DA, Falcon S (2024). RSQLite: SQLite Interface for R. R package version 2.3.9. https://CRAN.R-project.org/package=RSQLite

R Core Team (2024). R: A Language and Environment for Statistical Computing. R Foundation for Statistical Computing, Vienna, Austria. https://www.R-project.org/

USDA Forest Service (2025). Forest Inventory and Analysis Program database. Data accessed 6 January 2025 from https://apps.fs.usda.gov/fia/datamart/datamart.html

Wickham H, François R, Henry L, Müller K, Vaughan D (2023). dplyr: A Grammar of Data Manipulation. R package version 1.1.4. https://CRAN.R-project.org/package=dplyr
