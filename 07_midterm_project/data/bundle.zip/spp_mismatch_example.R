### Description: 
# This script describes how to download the Forest Inventory and Analysis (FIA) 
# SQLite database, query the TREE table, link individual tree measurements 
# through time, and evaluate changes in species identification code (SPCD). 
# 
# This script was run on a Windows PC with 196 GB RAM, so it may need to be 
# modified to run on a computer with less memory (e.g., pulling data state by 
# state or splitting data queries into smaller subsets). 
# 
# This script was written by Jonathan Knott (USDA Forest Service), with input 
# from Jianmin Wang (Purdue University) and David Walker (USDA Forest 
# Service). Contact info: jonathan.knott@usda.gov.

### Step 1: Set up workspace

# Load in packages
library(odbc)
library(dplyr)
library(RSQLite)
library(data.table)
library(rstudioapi)
options(scipen = 999) 

# Set path to folder where the FIA database was downloaded
shared_path <- rstudioapi::selectDirectory() # Select folder if using RStudio
database_name <- "SQLite_FIADB_ENTIRE_20250106/SQLite_FIADB_ENTIRE.db" # Set database name
# shared_path <- file.path("INSERT FILE PATH HERE") # Or type it in directly

### Step 2: Download FIA data
# The FIA database is available from the FIA Datamart at 
# https://apps.fs.usda.gov/fia/datamart/datamart.html.
# The full FIA database is around 62 GB in size, but this code can be run with
# the smaller state-level databases that are also available in the FIA Datamart.
# Note that the FIA database is constantly being updated, so final numbers of 
# trees may vary from those in the paper depending on when the FIA data is 
# downloaded.
# 
# To download the full FIA database from the FIA Datamart, in the "NFI Data" 
# tab, under "Additional Download Options" in the bottom left panel, select 
# "Entire FIADB SQLite Database" and save it to the shared_path folder. As noted
# above, the entire FIA database is quite large. You can  also select "Data 
# Type" as "SQLite", select a state of interest from the dropdown menu, and then
# choose the SQLite database under the "Data Available for Download" panel. Once
# downloaded, unzip the database to the shared_path location. 
# 
# The SQLite databases have the advantage over the CSV files because the data 
# can be queried without pulling all the tables into memory, as well as 
# maintaining the relationships between tables that would need to be hard coded 
# if working with the CSVs as data frames (or tibbles, data.tables, etc.). 
# Additionally, when the CSV files are opened in Excel, Excel sometimes converts 
# control number(CN, i.e., a long number that serves as a unique identifier for
# each tree measurement) into scientific notation and/or rounds the values, 
# making them no longer able to be linked to the rest of the FIA database.
# 
# There are a few ways to connect to the database, one of which is the RSQLite
# package as used below. Once a connection to the database is made with the 
# dbConnect() function, the dbSendQuery() and dbFetch() functions are used to 
# send a SQL query to the database and return the results in a data frame. 
# While very precise SQL queries can be made, this script uses a more general 
# approach to pulling lots of data, then using base R or dplyr to further clean 
# up the data into an analysis-ready form.

### Step 3: start connection to the database and pull tree data
# Note that the exact file name will need to be changed depending on when the
# database was downloaded and how you chose to name it.
con <- dbConnect(RSQLite::SQLite(), file.path(shared_path, database_name)) # connect to copy of FIA database

# First, pull the tree data
# Note, I'm pulling all attributes from the TREE table here, but you can select 
# only a few columns of interest instead of the full table. Stand origin code
# and some other plot level info is also pulled. The WHERE statement sets the
# criteria for which data are being pulled, so adjusting state code (statecd) to 
# only include a state of interest or adding in county code (countycd) to the 
# WHERE statement can get you a more precise selection of data from your area
# of interest.

# Get a count of the number of trees
ntree <- dbGetQuery(con, "SELECT COUNT(t.cn)
                            FROM ((TREE t -- from the tree table
                           INNER JOIN cond c ON t.plt_cn = c.plt_cn AND c.condid = t.condid) -- join the condition table
                           INNER JOIN plot p on c.plt_cn = p.cn) -- and join the plot table
                           WHERE p.plot_status_cd = 1 -- select plots with at least one forested condition
                              AND p.statecd IN (1,4,5,6,8,9,10,11,12,13,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,44,45,46,47,48,49,50,51,53,54,55,56) -- from CONUS states
                              AND p.kindcd IN (1, 2) -- where it's an annual inventory plot
                              AND t.subp BETWEEN 1 AND 4 -- and the trees fall on the four main subplots
                              AND t.statuscd = 1 -- and the trees are alive")

# Send the tree query to the database
tree.qry <- dbSendQuery(con, "SELECT t.*, -- all tree attibutes
                                    c.stdorgcd, -- stand origin code
                                    p.lat, -- latitude
                                    p.lon, -- longitude
                                    p.measyear, -- measurement year
                                    p.measmon, -- measurement month
                                    p.measday, -- measurement day
                                    p.intensity -- sample intensity
                           FROM ((TREE t -- from the tree table
                           INNER JOIN cond c ON t.plt_cn = c.plt_cn AND c.condid = t.condid) -- join the condition table
                           INNER JOIN plot p on c.plt_cn = p.cn) -- and join the plot table
                           WHERE p.plot_status_cd = 1 -- select plots with at least one forested condition
                              AND p.statecd IN (1,4,5,6,8,9,10,11,12,13,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,44,45,46,47,48,49,50,51,53,54,55,56) -- from CONUS states
                              AND p.kindcd IN (1, 2) -- where it's an annual inventory plot
                              AND t.subp BETWEEN 1 AND 4 -- and the trees fall on the four main subplots
                              AND t.statuscd = 1 -- and the trees are alive")

chnum <- 0 # Start the chunk number counter
chlen <- 10000 # I'm going to fetch results in chunks of 10000
ceiling(ntree/chlen) # Number of chunks that will be pulled
tree.sql1 <- vector("list", ceiling(as.numeric(ntree)/chlen)) # Create blank list
st <- Sys.time() # Start time
while(!dbHasCompleted(tree.qry)){ # while the query hasn't completed
  chunk <- dbFetch(tree.qry, chlen) %>% # Fetch a chunk of 10000 trees
    as_tibble() # Convert to tibble
  chnum <- chnum + 1 # Add 1 to the number of chunks pulled
  print(paste0(chnum*chlen, " (",round(100*(chnum*chlen)/ntree,1), "%) trees pulled at ", Sys.time())) # Makeshift progress tracker
  tree.sql1[[chnum]] <- chunk # Assign chunk to its slot in output list
}
dbClearResult(tree.qry) # Clear the query once it's completed
rm(tree.qry, chunk) # Remove the query and chunk from environment
tree.sql1 <- rbindlist(tree.sql1) # Use data.table package to rbind everything together
dbDisconnect(con) # Close connection to the database
sp <- Sys.time() # Stop time
sp-st # Check time elapsed

### Step 4: Build out the time series
# This series of steps begins with the most recent measurement of each tree,
# then it checks whether there have been any previous measurements. This step is
# repeated until there are no previous measurements of the tree. 

# Most recent measurements
step1 <- tree.sql1 %>% # Take all the trees
  select(CN, PREV_TRE_CN, SPCD) %>% # keep columns of interest
  filter(CN%in%PREV_TRE_CN==FALSE, !is.na(PREV_TRE_CN)) %>% # keep if it isn't a previous measurement and if it has been previously measured
  rename(SPCD1 = SPCD, PREV_TRE_CN1 = PREV_TRE_CN) # rename columns for joining later

# One step back
step2 <- tree.sql1 %>% # take all the trees 
  select(CN, PREV_TRE_CN, SPCD) %>% # keep columns of interest
  filter(CN%in%step1$PREV_TRE_CN1)%>% # keep if it was a previous measurement of the current trees
  rename(SPCD2 = SPCD, PREV_TRE_CN2 = PREV_TRE_CN) # rename columns for joining later

# Two steps back
step3 <- tree.sql1 %>% # take all the trees
  select(CN, PREV_TRE_CN, SPCD) %>% # keep columns of interest
  filter(CN%in%step2$PREV_TRE_CN2)%>% # keep if it was a previous measurement of the first previous measurement
  rename(SPCD3 = SPCD, PREV_TRE_CN3 = PREV_TRE_CN) # rename columns for joining later

# Three steps back
step4 <- tree.sql1 %>% # take all the trees
  select(CN, PREV_TRE_CN, SPCD) %>% # keep columns of interest
  filter(CN%in%step3$PREV_TRE_CN3)%>% # keep if it was a previous measurement of the second previous measurement
  rename(SPCD4 = SPCD, PREV_TRE_CN4 = PREV_TRE_CN) # rename columns for joining later

# Four steps back
step5 <- tree.sql1 %>% 
  select(CN, PREV_TRE_CN, SPCD) %>%
  filter(CN%in%step4$PREV_TRE_CN4)%>% # keep if it was a previous measurement of the third previous measurement
  rename(SPCD5 = SPCD, PREV_TRE_CN5 = PREV_TRE_CN)

# Five steps back
step6 <- tree.sql1 %>% 
  select(CN, PREV_TRE_CN, SPCD) %>%
  filter(CN%in%step5$PREV_TRE_CN5)%>% # keep if it was a previous measurement of the third previous measurement
  rename(SPCD6 = SPCD, PREV_TRE_CN6 = PREV_TRE_CN)

# Six steps back (no matches, but may be some in future FIA database updates)
step7 <- tree.sql1 %>% 
  select(CN, PREV_TRE_CN, SPCD) %>%
  filter(CN%in%step6$PREV_TRE_CN6)%>% # keep if it was a previous measurement of the third previous measurement
  rename(SPCD7 = SPCD, PREV_TRE_CN7 = PREV_TRE_CN)
nrow(step7)

### Step 5: Link remeasurements together and check for SPCD changes
# Once all of the steps back through time are created, join the data together
# so that we have each row as an individual tree, and each column as its species
# code (SPCD) and ID number (CN). Then, check for differences in SPCD through
# each remeasurement of the tree. 

mismatch <- step1 %>% # Take the most recent measurement
  left_join(step2, by = c("PREV_TRE_CN1" = "CN")) %>% # Join the previous measurement
  left_join(step3, by = c("PREV_TRE_CN2" = "CN")) %>% # Join the next previous measurement
  left_join(step4, by = c("PREV_TRE_CN3" = "CN")) %>% # Join the next previous measurement
  left_join(step5, by = c("PREV_TRE_CN4" = "CN")) %>% # Join the next previous measurement
  left_join(step6, by = c("PREV_TRE_CN5" = "CN")) %>% # Join the next previous measurement
  filter(!is.na(SPCD2)) %>% # Some most recent trees had a previous tree CN, but that tree was missing from the database, so remove those
  mutate(dif1 = abs(SPCD2-SPCD1), # See if SPCD changed between each remeasurement
         dif2 = abs(SPCD3-SPCD2), 
         dif3 = abs(SPCD4-SPCD3), 
         dif4 = abs(SPCD5-SPCD4), 
         dif5 = abs(SPCD6-SPCD5), 
         difs = case_when(dif1 > 0 ~ 1, # And assign a 1 if any of the SPCDs changed along the way
                          dif2 > 0 ~ 1,
                          dif3 > 0 ~ 1,
                          dif4 > 0 ~ 1,
                          dif5 > 0 ~ 1))

mism <- mismatch %>% # Take those mismatches
  filter(difs>0) %>% # Keep the ones that changed spcd 
  group_by(SPCD1) %>% # Group my the current spcd
  summarize(n = n()) %>% # And see how often it changed
  arrange(desc(n)) # Arrange by decreasing number

totals <- mismatch %>% # Take all the remeasured trees
  group_by(SPCD1) %>% # Group by spcd
  summarize(ntot = n()) %>% # Get total number for each species
  inner_join(mism) %>% # Join with the mismatch totals
  mutate(prop = n/ntot) %>% # Calculate the proportion mismatched
  arrange(desc(prop)) # Arrange by decreasing proportion

### Step 6: substitute in different SPCDs 
# Now that the table of tree measurements and SPCD changes through time 
# has been created, a variety of methods can be used to substitute in the
# different SPCDs. For example, in the paper we tested the differences between
# using the current or first SPCD for each tree. Additional methods could be
# used for updating SPCD, such as the most common SPCD through the remeasurement
# history (e.g., if a tree is currently recorded as green ash, but 3 out of 4 
# prior remeasurements were recorded white ash, change to white ash) or the most 
# frequent SPCD found in the same plot (e.g., a green ash that might be changed 
# as white ash if all the other trees are white ash).

mismatchm <- mismatch %>% # Take the trees through time data
  mutate(SPCD_T1 = ifelse(is.na(SPCD3), SPCD2, # If there wasn't a third step back, T1 is the second step back 
                          ifelse(is.na(SPCD4), SPCD3, # If there wasn't a fourth step back, T1 is the third step back
                                 ifelse(is.na(SPCD5), SPCD4,  # If there wasn't a fifth step back, T1 is the fourth step back
                                        ifelse(is.na(SPCD6), SPCD5, SPCD6)))), # If there wasn't a sixth step back, T1 is the fifth step back
         TRE_CN_T1 = ifelse(is.na(SPCD3), PREV_TRE_CN1, # And same logic for getting the tree CN identifiers
                            ifelse(is.na(SPCD4), PREV_TRE_CN2,
                                   ifelse(is.na(SPCD5), PREV_TRE_CN3, 
                                          ifelse(is.na(SPCD6), PREV_TRE_CN4, PREV_TRE_CN5)))))

# This mismatchm dataframe is what was exported and uploaded to the data 
# repository associated with this paper as "trees_through_time_20250429.csv".
# The CN column can be used to select data from the 'tree.sql1' data frame with 
# matching CNs, and the substitute in the different SPCD columns for the one 
# currently associated with each tree record.

